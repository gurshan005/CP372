import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/**
 * swing GUI client for BBoard server.
 * compile with: javac *.java 
 */
public class BBoardClientGUI extends JFrame {

    // basic models first 
    static final class Pt {
        final int x, y;
        Pt(int x, int y) { this.x = x; this.y = y; }
        @Override public boolean equals(Object o) { return (o instanceof Pt p) && p.x == x && p.y == y; }
        @Override public int hashCode() { return Objects.hash(x, y); }
    }

    static final class NoteView {
        final int id, x, y;
        final String color;
        final boolean pinned;
        final String message;
        NoteView(int id, int x, int y, String color, boolean pinned, String message) {
            this.id=id; this.x=x; this.y=y; this.color=color; this.pinned=pinned; this.message=message;
        }
    }

    // networking stuff below 


    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bboard-io");
        t.setDaemon(true);
        return t;
    });

    private NetClient client; // null when disconnected

    // handshake state
    private int boardW, boardH, noteW, noteH;
    private List<String> validColors = new ArrayList<>();

    // UI model state
    private final java.util.List<NoteView> notes = new ArrayList<>();
    private final Set<Pt> pins = new HashSet<>();

    // UI stuff for board 
    private final JTextField hostField = new JTextField("127.0.0.1");
    private final JTextField portField = new JTextField("4554");
    private final JLabel statusLabel = new JLabel("Disconnected");

    private final JTextField postX = new JTextField("2");
    private final JTextField postY = new JTextField("3");
    private final JComboBox<String> postColor = new JComboBox<>();
    private final JTextField postMsg = new JTextField("Meeting next Wednesday from 2 to 3");

    private final JComboBox<String> getColor = new JComboBox<>();
    private final JTextField getContainsX = new JTextField();
    private final JTextField getContainsY = new JTextField();
    private final JTextField getRefersTo = new JTextField();

    private final JTextArea logArea = new JTextArea(10, 30);

    // boardPanel is a separate class 
    private final BoardPanel boardPanel = new BoardPanel();

    // net client and handshake code: 
    static final class Handshake {
        final int boardW, boardH, noteW, noteH;
        final List<String> colors;
        final String readyLine;
        Handshake(int bw, int bh, int nw, int nh, List<String> colors, String readyLine) {
            this.boardW=bw; this.boardH=bh; this.noteW=nw; this.noteH=nh; this.colors=colors; this.readyLine=readyLine;
        }
    }

    static final class NetClient implements Closeable {
        private final Socket socket;
        private final BufferedReader in;
        private final BufferedWriter out;

        NetClient(String host, int port) throws IOException {
            socket = new Socket(host, port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
        }

        Handshake readHandshake() throws IOException {
            String board = in.readLine();
            String note = in.readLine();
            String colors = in.readLine();
            String ready = in.readLine();

            if (board == null || note == null || colors == null || ready == null) {
                // handle error here
                throw new IOException("Handshake incomplete.");
            }

            String[] b = board.trim().split("\\s+");
            String[] n = note.trim().split("\\s+");
            if (b.length != 3 || !b[0].equals("BOARD")) throw new IOException("Bad BOARD line: " + board);
            if (n.length != 3 || !n[0].equals("NOTE")) throw new IOException("Bad NOTE line: " + note);

            int bw = Integer.parseInt(b[1]);
            int bh = Integer.parseInt(b[2]);
            int nw = Integer.parseInt(n[1]);
            int nh = Integer.parseInt(n[2]);

            String[] c = colors.trim().split("\\s+");
            if (c.length < 2 || !c[0].equals("COLORS")) throw new IOException("Bad COLORS line: " + colors);
            List<String> colorList = new ArrayList<>();
            for (int i = 1; i < c.length; i++) colorList.add(c[i]);

            if (!ready.startsWith("OK")) throw new IOException("Bad READY line: " + ready);

            return new Handshake(bw, bh, nw, nh, colorList, ready);
        }

        synchronized String sendCommand(String cmd) throws IOException {
            out.write(cmd);
            out.write("\n");
            out.flush();
            String resp = in.readLine();
            if (resp == null) throw new IOException("Server disconnected.");
            return resp;
        }

        

synchronized List<String> readDataBlock() throws IOException {
    String first = in.readLine();
    if (first == null) {
        // handle error 
        throw new IOException("Server disconnected.");
    }

    if (!"DATA BEGIN".equals(first)) {
        throw new IOException("Expected DATA BEGIN but got: " + first);
    }

    List<String> lines = new ArrayList<>();
    while (true) {
        String s = in.readLine();
        if (s == null) {
            throw new IOException("Server disconnected.");
        }
        if ("DATA END".equals(s)) {
            break;
        }
        lines.add(s);
    }
    return lines;
}
            
         


        @Override public void close() throws IOException { socket.close(); }
    }

    // gui: 
    public BBoardClientGUI() {
        super("BBoard Client (Swing)");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel left = new JPanel(new BorderLayout(10, 10));
        left.setBorder(new EmptyBorder(12,12,12,12));
        left.add(headerPanel(), BorderLayout.NORTH);
        left.add(card("Board", boardPanel), BorderLayout.CENTER);

        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(12,12,12,12));
        right.add(card("Connection", connectionPanel()));
        right.add(Box.createVerticalStrut(10));
        right.add(card("Post", postPanel()));
        right.add(Box.createVerticalStrut(10));
        right.add(card("GET", getPanel()));
        right.add(Box.createVerticalStrut(10));
        right.add(card("Actions", actionsPanel()));
        right.add(Box.createVerticalStrut(10));
        right.add(card("Log", logPanel()));

        add(left, BorderLayout.CENTER);
        add(right, BorderLayout.EAST);

        styleStatusDisconnected();
        wireBoardClicks();

        setSize(1280, 720);
        setLocationRelativeTo(null);
    }

    private JPanel headerPanel() {
        JPanel p = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Network GUI: By Gurshan and Ryan");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        statusLabel.setOpaque(true);
        statusLabel.setBorder(new EmptyBorder(6,10,6,10));
        p.add(title, BorderLayout.WEST);
        p.add(statusLabel, BorderLayout.EAST);
        return p;
    }

    private JPanel connectionPanel() {
        JButton connect = new JButton("Connect");
        JButton disconnect = new JButton("Disconnect");
        connect.addActionListener(e -> connect());
        disconnect.addActionListener(e -> disconnect());

        JPanel p = new JPanel(new GridLayout(0,2,8,8));
        p.add(new JLabel("Host")); p.add(hostField);
        p.add(new JLabel("Port")); p.add(portField);
        p.add(connect); p.add(disconnect);
        return p;
    }

    private JPanel postPanel() {
        JButton post = new JButton("POST");
        post.addActionListener(e -> doPost());

        JPanel p = new JPanel(new GridLayout(0,2,8,8));
        p.add(new JLabel("x")); p.add(postX);
        p.add(new JLabel("y")); p.add(postY);
        p.add(new JLabel("color")); p.add(postColor);
        p.add(new JLabel("message")); p.add(postMsg);
        p.add(post); p.add(new JLabel(""));
        return p;
    }

    private JPanel getPanel() {
        JButton getAll = new JButton("GET All");
        JButton getPinsBtn = new JButton("GET PINS");
        JButton getFilter = new JButton("GET Filter");

        getAll.addActionListener(e -> sendGet("GET"));
        getPinsBtn.addActionListener(e -> sendPins());
        getFilter.addActionListener(e -> doGetFilter());

        getColor.addItem(""); // empty means missing criteria

        JPanel p = new JPanel(new GridLayout(0,2,8,8));
        p.add(new JLabel("color=")); p.add(getColor);

        JPanel contains = new JPanel(new GridLayout(1,2,8,8));
        contains.add(getContainsX);
        contains.add(getContainsY);
        p.add(new JLabel("contains=")); p.add(contains);

        p.add(new JLabel("refersTo=")); p.add(getRefersTo);

        p.add(getFilter); p.add(getAll);
        p.add(getPinsBtn); p.add(new JLabel(""));
        return p;
    }

    private JPanel actionsPanel() {
        JButton refresh = new JButton("Refresh");
        JButton shake = new JButton("SHAKE");
        JButton clear = new JButton("CLEAR");
        JButton disc = new JButton("DISCONNECT");

        refresh.addActionListener(e -> refreshAll());
        shake.addActionListener(e -> sendSimple("SHAKE", true));
        clear.addActionListener(e -> sendSimple("CLEAR", true));
        disc.addActionListener(e -> disconnect());

        JPanel p = new JPanel(new GridLayout(0,1,8,8));
        p.add(refresh); p.add(shake); p.add(clear); p.add(disc);

        JLabel hint = new JLabel("Left click board = PIN, Right click = UNPIN");
        hint.setFont(hint.getFont().deriveFont(Font.PLAIN, 12f));

        JPanel outer = new JPanel(new BorderLayout(8,8));
        outer.add(p, BorderLayout.CENTER);
        outer.add(hint, BorderLayout.SOUTH);
        return outer;
    }

    private JPanel logPanel() {
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        JScrollPane sp = new JScrollPane(logArea);
        sp.setPreferredSize(new Dimension(360, 180));
        JPanel p = new JPanel(new BorderLayout());
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    private JPanel card(String title, JComponent content) {
        JPanel card = new JPanel(new BorderLayout(8,8));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220,220,220)),
                new EmptyBorder(10,10,10,10)
        ));
        JLabel t = new JLabel(title);
        t.setFont(t.getFont().deriveFont(Font.BOLD, 13f));
        card.add(t, BorderLayout.NORTH);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    private void wireBoardClicks() {
        boardPanel.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (client == null || boardW <= 0 || boardH <= 0) return;

                int bx = boardPanel.toBoardX(e.getX(), boardW, boardH);
                int by = boardPanel.toBoardY(e.getY(), boardW, boardH);
                if (bx < 0 || by < 0 || bx >= boardW || by >= boardH) return;

                if (SwingUtilities.isLeftMouseButton(e)) {
                    sendSimple("PIN " + bx + " " + by, true);
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    sendSimple("UNPIN " + bx + " " + by, true);
                }
            }
        });
    }

    // commands

    //connect command
    private void connect() {
        if (client != null) { appendLog("Already connected."); return; }

        final String host = hostField.getText().trim();
        final int port;
        try { port = Integer.parseInt(portField.getText().trim()); }
        catch (Exception ex) { appendLog("Bad port."); return; }

        ioExecutor.submit(() -> {
            try {
                NetClient c = new NetClient(host, port);
                Handshake hs = c.readHandshake();

                SwingUtilities.invokeLater(() -> {
                    client = c;
                    boardW = hs.boardW; boardH = hs.boardH;
                    noteW = hs.noteW; noteH = hs.noteH;
                    validColors = new ArrayList<>(hs.colors);

                    postColor.removeAllItems();
                    getColor.removeAllItems();
                    getColor.addItem("");
                    for (String col : validColors) {
                        postColor.addItem(col);
                        getColor.addItem(col);
                    }
                    if (!validColors.isEmpty()) postColor.setSelectedIndex(0);

                    styleStatusConnected();
                    appendLog("Connected. " + hs.readyLine);
                    boardPanel.setData(notes, pins, boardW, boardH, noteW, noteH);
                    boardPanel.repaint();

                    
                    refreshAll();
                });

            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    appendLog("Connect ERROR: " + ex.getMessage());
                    styleStatusDisconnected();
                });
            }
        });
    }


    //disconnect function

    private void disconnect() {
        if (client == null) { appendLog("Not connected."); return; }
        ioExecutor.submit(() -> {
            try { appendLogLater("> DISCONNECT\n" + client.sendCommand("DISCONNECT")); }
            catch (Exception ignored) {}
            finally {
                try { client.close(); } catch (Exception ignored2) {}
                SwingUtilities.invokeLater(() -> {
                    client = null;
                    notes.clear(); pins.clear();
                    boardW = boardH = noteW = noteH = 0;
                    validColors.clear();
                    styleStatusDisconnected();
                    boardPanel.setData(Collections.emptyList(), Collections.emptySet(), 0,0,0,0);
                    boardPanel.repaint();
                    appendLog("Disconnected.");
                });
            }
        });
    }

    // doPost function 
    private void doPost() {
        if (client == null) {
        appendLog("POST failed: not connected.");
        return;
    }

    String x = postX.getText().trim();
    String y = postY.getText().trim();
    String color = (String) postColor.getSelectedItem();
    String msg = postMsg.getText().trim();

    if (x.isEmpty() || y.isEmpty() || color == null || color.isBlank() || msg.isEmpty()) {
        appendLog("POST failed: fill x, y, color, and message.");
        return;
    }

    String cmd = "POST " + x + " " + y + " " + color + " " + msg;

    // debug
    appendLog("> " + cmd);

    sendSimple(cmd, true);
}

    private void doGetFilter() {
        if (client == null) { appendLog("Connect first."); return; }
        StringBuilder sb = new StringBuilder("GET");

        String c = (String) getColor.getSelectedItem();
        if (c != null && !c.isBlank()) sb.append(" color=").append(c);

        String cx = getContainsX.getText().trim();
        String cy = getContainsY.getText().trim();
        if (!cx.isEmpty() || !cy.isEmpty()) {
            if (cx.isEmpty() || cy.isEmpty()) { appendLog("contains needs both x and y."); return; }
            sb.append(" contains=").append(cx).append(" ").append(cy);
        }

        String ref = getRefersTo.getText().trim();
        if (!ref.isEmpty()) sb.append(" refersTo=").append(ref);

        sendGet(sb.toString());
    }

    // refreshAll 

    private void refreshAll() {
        if (client == null) return;
        ioExecutor.submit(() -> {
            try {
                String r1 = client.sendCommand("GET");
                List<String> d1 = client.readDataBlock();
                String r2 = client.sendCommand("GET PINS");
                List<String> d2 = client.readDataBlock();

                SwingUtilities.invokeLater(() -> {
                    appendLog("> GET\n" + r1);
                    applyNotes(d1);
                    appendLog("> GET PINS\n" + r2);
                    applyPins(d2);

                    boardPanel.setData(notes, pins, boardW, boardH, noteW, noteH);
                    boardPanel.repaint();
                });

            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> appendLog("Refresh ERROR: " + ex.getMessage()));
            }
        });
    }

    private void sendSimple(String cmd, boolean refreshAfter) {
    ioExecutor.submit(() -> {
        try {
            String resp = client.sendCommand(cmd);

            SwingUtilities.invokeLater(() -> {
                appendLog("> " + cmd);
                appendLog(resp);              //  show server reply (OK/ERROR)
            });

            if (refreshAfter) refreshAll();

        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> appendLog("I/O ERROR: " + ex.getMessage()));
        }
    });
}



    private void sendGet(String cmd) {
        ioExecutor.submit(() -> {
            try {
                String resp = client.sendCommand(cmd);
                List<String> data = client.readDataBlock();
                SwingUtilities.invokeLater(() -> {
                    appendLog("> " + cmd + "\n" + resp);
                    applyNotes(data);
                    boardPanel.setData(notes, pins, boardW, boardH, noteW, noteH);
                    boardPanel.repaint();
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> appendLog("GET ERROR: " + ex.getMessage()));
            }
        });
    }

    private void sendPins() {
        ioExecutor.submit(() -> {
            try {
                String resp = client.sendCommand("GET PINS");
                List<String> data = client.readDataBlock();
                SwingUtilities.invokeLater(() -> {
                    appendLog("> GET PINS\n" + resp);
                    applyPins(data);
                    boardPanel.setData(notes, pins, boardW, boardH, noteW, noteH);
                    boardPanel.repaint();
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> appendLog("GET PINS ERROR: " + ex.getMessage()));
            }
        });
    }

    private void applyNotes(List<String> lines) {
        notes.clear();
        for (String s : lines) {
            if (!s.startsWith("NOTE ")) continue;
            String[] parts = s.split("\\s+", 7);
            if (parts.length < 7) continue;
            try {
                int id = Integer.parseInt(parts[1]);
                int x = Integer.parseInt(parts[2]);
                int y = Integer.parseInt(parts[3]);
                String color = parts[4];
                boolean pinned = parts[5].equalsIgnoreCase("PINNED");
                String msg = parts[6];
                notes.add(new NoteView(id, x, y, color, pinned, msg));
            } catch (Exception ignored) {}
        }
        // unpinned first then pinned last (so pinned drawn on top)
        notes.sort((a, b) -> {
            if (a.pinned != b.pinned) return Boolean.compare(a.pinned, b.pinned);
            return Integer.compare(a.id, b.id);
        });
    }

    private void applyPins(List<String> lines) {
        pins.clear();
        for (String s : lines) {
            if (!s.startsWith("PIN ")) continue;
            String[] p = s.split("\\s+");
            if (p.length != 3) continue;
            try {
                pins.add(new Pt(Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            } catch (Exception ignored) {}
        }
    }

    private void appendLog(String t) {
        logArea.append(t + "\n\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void appendLogLater(String t) {
        SwingUtilities.invokeLater(() -> appendLog(t));
    }

    private void styleStatusConnected() {
        statusLabel.setText("Connected");
        statusLabel.setBackground(new Color(230, 255, 235));
        statusLabel.setForeground(new Color(20, 120, 40));
    }

    private void styleStatusDisconnected() {
        statusLabel.setText("Disconnected");
        statusLabel.setBackground(new Color(235, 240, 255));
        statusLabel.setForeground(new Color(20, 40, 120));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new BBoardClientGUI().setVisible(true);
        });
    }
}

class BoardPanel extends JPanel {

    private java.util.List<BBoardClientGUI.NoteView> notes = Collections.emptyList();
    private Set<BBoardClientGUI.Pt> pins = Collections.emptySet();
    private int boardW, boardH, noteW, noteH;

    BoardPanel() {
        setPreferredSize(new Dimension(840, 520));
        setBackground(new Color(250, 250, 252));
    }

    void setData(java.util.List<BBoardClientGUI.NoteView> notes,
                 Set<BBoardClientGUI.Pt> pins,
                 int boardW, int boardH, int noteW, int noteH) {
        this.notes = (notes == null) ? Collections.emptyList() : new ArrayList<>(notes);
        this.pins = (pins == null) ? Collections.emptySet() : new HashSet<>(pins);
        this.boardW = boardW; this.boardH = boardH; this.noteW = noteW; this.noteH = noteH;
    }

    double scale() {
        if (boardW <= 0 || boardH <= 0) return 1.0;
        double sx = (getWidth() - 20.0) / boardW;
        double sy = (getHeight() - 20.0) / boardH;
        return Math.max(2.0, Math.min(sx, sy));
    }

    int toBoardX(int px, int boardW, int boardH) {
        if (boardW <= 0 || boardH <= 0) return -1;
        return (int) Math.floor((px - 10.0) / scale());
    }

    int toBoardY(int py, int boardW, int boardH) {
        if (boardW <= 0 || boardH <= 0) return -1;
        return (int) Math.floor((py - 10.0) / scale());
    }

    @Override protected void paintComponent(Graphics gg) {
        super.paintComponent(gg);
        Graphics2D g2 = (Graphics2D) gg.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (boardW <= 0 || boardH <= 0) {
            g2.setColor(new Color(90, 100, 120));
            g2.drawString("Connect to a server to render the board.", 20, 30);
            g2.dispose();
            return;
        }

        double s = scale();
        int ox = 10, oy = 10;
        int bwPx = (int) Math.round(boardW * s);
        int bhPx = (int) Math.round(boardH * s);

        g2.setColor(new Color(245, 246, 250));
        g2.fillRoundRect(ox, oy, bwPx, bhPx, 18, 18);

        g2.setColor(new Color(225, 228, 236));
        for (int x = 0; x <= boardW; x += Math.max(1, noteW)) {
            int px = ox + (int) Math.round(x * s);
            g2.drawLine(px, oy, px, oy + bhPx);
        }
        for (int y = 0; y <= boardH; y += Math.max(1, noteH)) {
            int py = oy + (int) Math.round(y * s);
            g2.drawLine(ox, py, ox + bwPx, py);
        }

        // notes (already sorted in client)
        for (BBoardClientGUI.NoteView n : notes) {
            drawNote(g2, n, ox, oy, s);
        }

        // pins
        for (BBoardClientGUI.Pt p : pins) {
            drawPin(g2, p, ox, oy, s);
        }

        g2.setColor(new Color(180, 185, 200));
        g2.setStroke(new BasicStroke(2f));
        g2.drawRoundRect(ox, oy, bwPx, bhPx, 18, 18);
        g2.dispose();
    }

    private void drawNote(Graphics2D g2, BBoardClientGUI.NoteView n, int ox, int oy, double s) {
        int x = ox + (int) Math.round(n.x * s);
        int y = oy + (int) Math.round(n.y * s);
        int w = (int) Math.round(noteW * s);
        int h = (int) Math.round(noteH * s);

        Color fill = mapColor(n.color);
        float alpha = n.pinned ? 0.95f : 0.78f;

        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
        g2.setColor(fill);
        g2.fillRoundRect(x, y, w, h, 16, 16);

        g2.setComposite(AlphaComposite.SrcOver);
        g2.setColor(n.pinned ? new Color(30, 30, 30) : new Color(80, 85, 95));
        g2.setStroke(new BasicStroke(n.pinned ? 2.2f : 1.2f));
        g2.drawRoundRect(x, y, w, h, 16, 16);

        g2.setColor(new Color(25, 25, 25));
        g2.setFont(getFont().deriveFont(Font.BOLD, 12f));
        g2.drawString("#" + n.id + (n.pinned ? "  \uD83D\uDCCC" : ""), x + 8, y + 16);

        g2.setFont(getFont().deriveFont(Font.PLAIN, 12f));
        String msg = n.message;
        if (msg.length() > 26) msg = msg.substring(0, 26) + "…";
        g2.drawString(msg, x + 8, y + 32);
    }

    private void drawPin(Graphics2D g2, BBoardClientGUI.Pt p, int ox, int oy, double s) {
        int px = ox + (int) Math.round(p.x * s);
        int py = oy + (int) Math.round(p.y * s);
        int r = 6;
        g2.setColor(new Color(230, 50, 50));
        g2.fillOval(px - r, py - r, r*2, r*2);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(1.2f));
        g2.drawOval(px - r, py - r, r*2, r*2);
    }

    private Color mapColor(String name) {
        String c = name.toUpperCase(Locale.ROOT);
        switch (c) {
            case "RED": return new Color(255, 120, 120);
            case "GREEN": return new Color(120, 220, 140);
            case "BLUE": return new Color(135, 190, 255);
            case "YELLOW": return new Color(255, 230, 120);
            case "WHITE": return new Color(245, 245, 245);
            case "PINK": return new Color(255, 170, 210);
            case "ORANGE": return new Color(255, 190, 120);
            case "PURPLE": return new Color(195, 170, 255);
            default: return new Color(255, 230, 120);
        }
    }
}
